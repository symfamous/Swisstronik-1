package meta

var (
	buildversion   = ""
	releaseversion = "0.4.0"
	releasedate    = "2021-10-30"
	conceptdoi     = "10.5281/zenodo.4625263"
	doi            = "10.5281/zenodo.5622943"
	zenodoid       = "5622943"
)
