---
slug: /hardware-requirements
sidebar_position: 5
title: Juno Full Node Hardware Requirements
---

This outlines the hardware specifications required to run a Juno full node, including both minimal and recommended requirements.

## Minimal Hardware Specifications

- **CPU**: 2+ cores
- **RAM**: 4GB+
- **Storage**: 200GiB (SSD recommended; note: storage requirements will increase over time)

## Recommended Hardware Specifications

- **CPU**: Fast CPU with 4+ cores
- **RAM**: 8GB or more
- **Storage**: High-performance SSD with more than 200GiB, to accommodate future growth

**Note**: The above specifications serve as a guideline. While the minimal requirements are sufficient for basic operations, the recommended specifications ensure optimal performance and future scalability. Always refer to the [official Juno documentation](https://juno.nethermind.io/) for the most current information and updates.
