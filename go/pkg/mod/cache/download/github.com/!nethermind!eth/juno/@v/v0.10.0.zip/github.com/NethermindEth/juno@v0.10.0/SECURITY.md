# Security Policy

## Supported Versions

Currently the project is in the early setup mode so no version are supported from security perspective.
Please create a GitHub issue if you think this information is out of date.

## Reporting a Vulnerability

Please send a report to security@nethermind.io
