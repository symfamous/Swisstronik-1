// Package cli provides utilities for building subcommand-based command line interfaces.
package cli
