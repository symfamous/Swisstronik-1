// Package algtest provides algorithm test suites.
package algtest
