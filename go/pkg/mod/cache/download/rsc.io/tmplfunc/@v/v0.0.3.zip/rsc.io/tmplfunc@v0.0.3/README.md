[![Documentation](https://pkg.go.dev/badge/rsc.io/tmplfunc.svg)](https://pkg.go.dev/rsc.io/tmplfunc)

Package tmplfunc provides an extension of Go templates
in which templates can be invoked as if they were functions.

See the [package documentation](https://pkg.go.dev/rsc.io/tmplfunc) for details.


