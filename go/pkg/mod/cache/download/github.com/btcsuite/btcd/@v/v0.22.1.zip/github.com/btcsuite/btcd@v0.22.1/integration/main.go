// Copyright (c) 2016 The btcsuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package integration

// This file only exists to prevent warnings due to no buildable source files
// when the build tag for enabling the tests is not specified.
