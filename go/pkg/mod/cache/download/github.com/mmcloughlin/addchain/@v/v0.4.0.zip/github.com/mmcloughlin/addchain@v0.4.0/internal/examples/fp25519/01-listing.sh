addchain gen inv.acc
