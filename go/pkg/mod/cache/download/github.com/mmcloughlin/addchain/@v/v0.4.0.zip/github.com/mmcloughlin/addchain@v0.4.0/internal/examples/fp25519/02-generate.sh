addchain gen -tmpl inv.tmpl inv.acc | gofmt > inv.go
